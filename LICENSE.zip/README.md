# jsondb
A simple typescript library for storing and querying information from a .json file, kind of like a database. Really great alternative for @replit/database.
