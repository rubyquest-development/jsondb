interface DatabaseSchema {
    [collection: string]: any[];
}

export { DatabaseSchema } 